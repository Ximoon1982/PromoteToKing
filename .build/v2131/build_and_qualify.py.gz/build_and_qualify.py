#!/usr/bin/env python3
from __future__ import annotations
import hashlib, os, shutil, subprocess, sys, tempfile, textwrap, zipfile
from pathlib import Path

REPO=Path.cwd()
QUAL='03c476147694220764c0b33448429d14c5e8d6c1'
BASES=[
 ('base','9c2f08e3f59945ae983f30d6b214f10140dbd345'),
 ('pagination','1c17ca07fdf2b20ac872ff24fb92d87750f6938b'),
 ('fallback','385faccdbf18725b4487144b8a7cf3e2630ed1b1'),
]
RUNTIME=[
 'VERSION',
 'server/team-points-green/src/GreenCompatibility.php',
 'server/team-points-green/src/GreenRepository.php',
 'server/team-points/src/McaResultsCronService.php',
 'server/team-points/sql/analytics-schema.sql',
 'server/team-points-green/tools/converge-v2.13.1.php',
]
PKGNAME='PromoteToKing_v2.13.1_INCREMENTAL_FROM_2.13.0_r1'
DIST=REPO/'dist-v2131-installer'
PKG=DIST/PKGNAME
OVERLAY=PKG/'overlay'
MYSQL_HOST=os.getenv('P2K_TEST_DB_HOST','127.0.0.1')
MYSQL_PORT=os.getenv('P2K_TEST_DB_PORT','3306')
MYSQL_USER=os.getenv('P2K_TEST_DB_USER','root')
MYSQL_PASS=os.getenv('P2K_TEST_DB_PASS','root')


def run(args, *, cwd=None, env=None, check=True, input=None, text=True):
    print('+',' '.join(map(str,args)),flush=True)
    return subprocess.run(args,cwd=cwd,env=env,check=check,input=input,text=text)

def capture(args, *, cwd=None, binary=False):
    return subprocess.check_output(args,cwd=cwd,text=not binary)

def sha_bytes(b:bytes)->str: return hashlib.sha256(b).hexdigest()
def sha_file(p:Path)->str: return sha_bytes(p.read_bytes())
def git_bytes(ref:str,path:str)->bytes: return subprocess.check_output(['git','show',f'{ref}:{path}'])
def write(p:Path,s:str,mode=0o644): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s); p.chmod(mode)

def q(s:str)->str:
    return "'"+s.replace("'","'\\''")+"'"

PREFLIGHT=r'''<?php
declare(strict_types=1);
if(PHP_VERSION_ID<80000){fwrite(STDERR,"PHP 8+ required\n");exit(2);}
$root=rtrim((string)($argv[1]??''),"/\\");
if($root===''||!is_dir($root)){fwrite(STDERR,"usage: preflight-v2131-schema.php ROOT\n");exit(2);}
require_once $root.'/server/team-points-green/src/GreenConfig.php';
use P2K\Green\GreenConfig;
function col(PDO $pdo,string $table,string $column): bool{$q=$pdo->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?');$q->execute([$table,$column]);return (int)$q->fetchColumn()>0;}
function idx(PDO $pdo,string $table,string $index): bool{$q=$pdo->prepare('SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name=? AND index_name=?');$q->execute([$table,$index]);return (int)$q->fetchColumn()>0;}
function tbl(PDO $pdo,string $table): bool{$q=$pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?');$q->execute([$table]);return (int)$q->fetchColumn()>0;}
function addcol(PDO $pdo,string $table,string $column,string $definition): void{if(!col($pdo,$table,$column))$pdo->exec('ALTER TABLE '.$table.' ADD COLUMN '.$column.' '.$definition);if(!col($pdo,$table,$column))throw new RuntimeException('missing column after repair '.$table.'.'.$column);}
function addidx(PDO $pdo,string $table,string $index,string $definition): void{if(!idx($pdo,$table,$index))$pdo->exec('ALTER TABLE '.$table.' ADD INDEX '.$index.' '.$definition);if(!idx($pdo,$table,$index))throw new RuntimeException('missing index after repair '.$table.'.'.$index);}
try{
  $core=GreenConfig::core();$analytics=GreenConfig::analytics();
  $hasState=tbl($core,'p2k_g_state');$hasMatches=tbl($core,'p2k_g_matches');
  if(!$hasState||!$hasMatches)throw new RuntimeException('Green base schema is incomplete or not installed.');
  addcol($core,'p2k_g_matches','max_rating','SMALLINT UNSIGNED NULL');
  addidx($core,'p2k_g_matches','idx_g_match_discovered','(verified_club_slug,club_verified,created_at,match_id)');
  if(tbl($core,'p2k_tp_match_metadata')){
    addcol($core,'p2k_tp_match_metadata','max_rating','SMALLINT UNSIGNED NULL AFTER rated_board_count');
    addidx($core,'p2k_tp_match_metadata','idx_tp_match_discovered','(club_slug,first_discovered_at)');
  }
  if(tbl($analytics,'p2k_lr_sync_state')){
    $cols=[
      'discovery_failure_streak'=>'INT UNSIGNED NOT NULL DEFAULT 0 AFTER error_count',
      'last_discovery_attempt_at'=>'DATETIME NULL AFTER discovery_failure_streak',
      'last_successful_discovery_at'=>'DATETIME NULL AFTER last_discovery_attempt_at',
      'last_index_page_fingerprint'=>'CHAR(64) NULL AFTER last_successful_discovery_at',
    ];
    foreach($cols as $name=>$def)addcol($analytics,'p2k_lr_sync_state',$name,$def);
  }
  echo "v2.13.1 schema preflight verified\n";
}catch(Throwable $e){fwrite(STDERR,'v2.13.1 schema preflight failed: '.$e->getMessage().PHP_EOL);exit(1);}
'''

INSTALLER=r'''#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-}"
[[ -n "$ROOT" && -d "$ROOT" ]] || { echo "usage: $0 /path/to/PromoteToKing" >&2; exit 2; }
ROOT="$(cd "$ROOT" && pwd -P)"
PKG="$(cd "$(dirname "$0")" && pwd -P)"
PHP_BIN="${P2K_PHP_BIN:-}"
if [[ -z "$PHP_BIN" ]]; then for p in /usr/bin/php8.5-cli /usr/bin/php8.4-cli /usr/bin/php8.3-cli /usr/bin/php8.2-cli php; do if command -v "$p" >/dev/null 2>&1; then PHP_BIN="$(command -v "$p")"; break; fi; done; fi
[[ -n "$PHP_BIN" ]] || { echo "PHP 8+ CLI not found" >&2; exit 2; }
"$PHP_BIN" -r 'exit(PHP_VERSION_ID>=80000?0:1);' || { echo "PHP 8+ CLI required: $PHP_BIN" >&2; exit 2; }
command -v sha256sum >/dev/null || { echo "sha256sum required" >&2; exit 2; }
cd "$PKG"
sha256sum -c PACKAGE-SHA256SUMS.txt
FILES=(
 'VERSION'
 'server/team-points-green/src/GreenCompatibility.php'
 'server/team-points-green/src/GreenRepository.php'
 'server/team-points/src/McaResultsCronService.php'
 'server/team-points/sql/analytics-schema.sql'
 'server/team-points-green/tools/converge-v2.13.1.php'
)
allowed_hash(){ local rel="$1" got="$2"; awk -F '\t' -v p="$rel" -v h="$got" '$1==p && $3==h{ok=1} END{exit ok?0:1}' "$PKG/BASELINES.tsv" || awk -F '\t' -v p="$rel" -v h="$got" '$1==p && $2==h{ok=1} END{exit ok?0:1}' "$PKG/TARGETS.tsv"; }
for rel in "${FILES[@]}"; do
  live="$ROOT/$rel"
  if [[ "$rel" == 'server/team-points-green/tools/converge-v2.13.1.php' && ! -e "$live" ]]; then continue; fi
  [[ -f "$live" && ! -L "$live" ]] || { echo "Unsupported/missing production file: $rel" >&2; exit 2; }
  h="$(sha256sum "$live"|awk '{print $1}')"
  allowed_hash "$rel" "$h" || { echo "Unsupported source identity for $rel: $h" >&2; exit 2; }
done
TMP="$(mktemp -d "$ROOT/.p2k-v2131-install.XXXXXX")"
BACK="$TMP/backup"; STAGE="$TMP/stage"; mkdir -p "$BACK" "$STAGE"
activated=0
cleanup(){ rm -rf "$TMP"; }
rollback(){
  [[ $activated -eq 1 ]] || return 0
  echo "Install failed after activation; restoring source files..." >&2
  for rel in "${FILES[@]}"; do
    mkdir -p "$(dirname "$ROOT/$rel")"
    if [[ -f "$BACK/$rel" ]]; then cp -p "$BACK/$rel" "$ROOT/$rel"; else rm -f "$ROOT/$rel"; fi
  done
}
trap 'rc=$?; if [[ $rc -ne 0 ]]; then rollback || true; fi; cleanup; exit $rc' EXIT
for rel in "${FILES[@]}"; do
  [[ -f "$ROOT/$rel" ]] && { mkdir -p "$(dirname "$BACK/$rel")"; cp -p "$ROOT/$rel" "$BACK/$rel"; }
  mkdir -p "$(dirname "$STAGE/$rel")"; cp -p "$PKG/overlay/$rel" "$STAGE/$rel"
done
for rel in server/team-points-green/src/GreenCompatibility.php server/team-points-green/src/GreenRepository.php server/team-points/src/McaResultsCronService.php server/team-points-green/tools/converge-v2.13.1.php; do "$PHP_BIN" -l "$STAGE/$rel" >/dev/null; done
P2K_TP_CONFIG="${P2K_TP_CONFIG:-}" "$PHP_BIN" "$PKG/preflight-v2131-schema.php" "$ROOT"
for rel in "${FILES[@]}"; do mkdir -p "$(dirname "$ROOT/$rel")"; cp -p "$STAGE/$rel" "$ROOT/$rel"; done
activated=1
if [[ "${P2K_INSTALLER_TEST_FAIL_AFTER_ACTIVATION:-0}" == 1 ]]; then echo "qualification failure injection" >&2; exit 3; fi
while IFS=$'\t' read -r rel expected; do [[ -z "$rel" ]] && continue; got="$(sha256sum "$ROOT/$rel"|awk '{print $1}')"; [[ "$got" == "$expected" ]] || { echo "Post-install byte verification failed for $rel" >&2; exit 1; }; done < "$PKG/TARGETS.tsv"
for rel in server/team-points-green/src/GreenCompatibility.php server/team-points-green/src/GreenRepository.php server/team-points/src/McaResultsCronService.php server/team-points-green/tools/converge-v2.13.1.php; do "$PHP_BIN" -l "$ROOT/$rel" >/dev/null; done
P2K_TP_CONFIG="${P2K_TP_CONFIG:-}" "$PHP_BIN" "$ROOT/server/team-points-green/tools/converge-v2.13.1.php"
[[ "$(tr -d '\r\n' < "$ROOT/VERSION")" == '2.13.1' ]] || { echo "VERSION verification failed" >&2; exit 1; }
activated=0
cleanup
trap - EXIT
echo "Promote to King v2.13.1 incremental installation verified successfully."
'''

README='''Promote to King v2.13.1 incremental installer\n\nQualified application source: 03c476147694220764c0b33448429d14c5e8d6c1\nSupported v2.13.0 source line: 9c2f08e3..., 1c17ca07..., 385faccd... and safe per-file mixtures of those exact qualified bytes.\n\nThe installer is scope-limited. It replaces only VERSION plus the v2.13.1 Green/MCA runtime files listed in TARGETS.tsv. It does not modify static assets, configuration, user data, storage, or CRON configuration.\n\nBefore activating new source it performs additive database repairs required by v2.13.1, then after activation it runs the qualified full Green physical-schema convergence verifier. On a post-activation source failure, touched source files are restored. Additive DB repairs are intentionally retained because they are backwards-compatible.\n\nIONOS production command (use PHP 8.5 explicitly):\nP2K_PHP_BIN=/usr/bin/php8.5-cli bash install-promote-to-king-v2.13.1.sh /kunden/homepages/43/d141198007/htdocs/PromoteToKing\n'''

IDENTITY=f'''release=v2.13.1\nqualified_head={QUAL}\npackage={PKGNAME}.zip\nscope=incremental runtime/schema convergence only\nstatic_assets=unchanged\n'''


def build_package():
    if DIST.exists(): shutil.rmtree(DIST)
    OVERLAY.mkdir(parents=True)
    # Assert build checkout preserves qualified application bytes.
    for rel in RUNTIME:
        target=git_bytes(QUAL,rel)
        current=(REPO/rel).read_bytes()
        if current!=target: raise RuntimeError(f'build checkout differs from qualified application bytes: {rel}')
        dst=OVERLAY/rel; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_bytes(target)
    write(PKG/'preflight-v2131-schema.php',PREFLIGHT)
    write(PKG/'install-promote-to-king-v2.13.1.sh',INSTALLER,0o755)
    write(PKG/'README.txt',README)
    write(PKG/'RELEASE-IDENTITY.txt',IDENTITY)
    # path, label, sha256
    lines=[]
    for label,ref in BASES:
        for rel in RUNTIME[:-1]: lines.append(f'{rel}\t{label}:{ref}\t{sha_bytes(git_bytes(ref,rel))}')
    (PKG/'BASELINES.tsv').write_text('\n'.join(lines)+'\n')
    targets=[]
    for rel in RUNTIME: targets.append(f'{rel}\t{sha_file(OVERLAY/rel)}')
    (PKG/'TARGETS.tsv').write_text('\n'.join(targets)+'\n')
    # Package checksum excludes itself and qualification-only files.
    files=[]
    for p in sorted(PKG.rglob('*')):
        if p.is_file() and p.name!='PACKAGE-SHA256SUMS.txt': files.append(p)
    sums=''.join(f'{sha_file(p)}  {p.relative_to(PKG).as_posix()}\n' for p in files)
    (PKG/'PACKAGE-SHA256SUMS.txt').write_text(sums)
    run(['bash','-n',str(PKG/'install-promote-to-king-v2.13.1.sh')])
    run(['php','-l',str(PKG/'preflight-v2131-schema.php')])
    for rel in RUNTIME:
        if rel.endswith('.php'): run(['php','-l',str(OVERLAY/rel)])


def mysql(sql:str, db:str|None=None):
    args=['mariadb',f'-h{MYSQL_HOST}',f'-P{MYSQL_PORT}',f'-u{MYSQL_USER}',f'-p{MYSQL_PASS}']
    if db: args.append(db)
    run(args,input=sql)

def load_sql(db:str,p:Path): mysql(p.read_text(),db)
def dbnames(tag): return f'p2k_i_{tag}_c',f'p2k_i_{tag}_a'

def setup_db(fixture:Path,tag:str):
    core,an=dbnames(tag)
    mysql(f'DROP DATABASE IF EXISTS `{core}`; DROP DATABASE IF EXISTS `{an}`; CREATE DATABASE `{core}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci; CREATE DATABASE `{an}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;')
    # Start from current schemas, then reproduce the production physical drift repaired by v2.13.1.
    load_sql(core,REPO/'server/team-points-green/sql/core-schema.sql')
    load_sql(an,REPO/'server/team-points-green/sql/analytics-schema.sql')
    load_sql(core,REPO/'server/team-points/sql/core-schema.sql')
    load_sql(an,REPO/'server/team-points/sql/analytics-schema.sql')
    mysql('ALTER TABLE p2k_g_matches DROP INDEX idx_g_match_discovered; ALTER TABLE p2k_g_matches DROP COLUMN max_rating; ALTER TABLE p2k_tp_match_metadata DROP INDEX idx_tp_match_discovered; ALTER TABLE p2k_tp_match_metadata DROP COLUMN max_rating;',core)
    mysql('ALTER TABLE p2k_lr_sync_state DROP COLUMN last_index_page_fingerprint, DROP COLUMN last_successful_discovery_at, DROP COLUMN last_discovery_attempt_at, DROP COLUMN discovery_failure_streak;',an)
    cfg=fixture/'server/team-points-green/config/green.local.php'; cfg.parent.mkdir(parents=True,exist_ok=True)
    cfg.write_text("<?php\ndeclare(strict_types=1);\nreturn "+repr_php({'databases':{'core':{'host':MYSQL_HOST,'port':int(MYSQL_PORT),'name':core,'user':MYSQL_USER,'password':MYSQL_PASS,'charset':'utf8mb4','connect_timeout_seconds':5},'analytics':{'host':MYSQL_HOST,'port':int(MYSQL_PORT),'name':an,'user':MYSQL_USER,'password':MYSQL_PASS,'charset':'utf8mb4','connect_timeout_seconds':5}},'app':{'cron_token':'qualification'}})+";\n")
    tp=fixture/'.qualification-tp-config.php'; tp.write_text("<?php\nreturn ['app'=>['club_slug'=>'promote-to-king'],'storage'=>[]];\n")
    return core,an,tp

def repr_php(v):
    if v is None:return 'NULL'
    if v is True:return 'true'
    if v is False:return 'false'
    if isinstance(v,(int,float)):return str(v)
    if isinstance(v,str):return "'"+v.replace('\\','\\\\').replace("'","\\'")+"'"
    if isinstance(v,list):return '['+','.join(repr_php(x) for x in v)+']'
    if isinstance(v,dict):return '['+','.join(repr_php(str(k))+'=>'+repr_php(x) for k,x in v.items())+']'
    raise TypeError(type(v))

def verify_db(core,an):
    sql="""SELECT IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='p2k_g_matches' AND column_name='max_rating')=1,'OK','FAIL'); SELECT IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='p2k_g_matches' AND index_name='idx_g_match_discovered')>0,'OK','FAIL'); SELECT IF((SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='p2k_tp_match_metadata' AND column_name='max_rating')=1,'OK','FAIL'); SELECT IF((SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='p2k_tp_match_metadata' AND index_name='idx_tp_match_discovered')>0,'OK','FAIL');"""
    out=capture(['mariadb','-N',f'-h{MYSQL_HOST}',f'-P{MYSQL_PORT}',f'-u{MYSQL_USER}',f'-p{MYSQL_PASS}',core,'-e',sql])
    if out.split()!=['OK']*4: raise RuntimeError('core DB repair verification failed: '+out)
    sql="SELECT column_name FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='p2k_lr_sync_state' AND column_name IN ('discovery_failure_streak','last_discovery_attempt_at','last_successful_discovery_at','last_index_page_fingerprint') ORDER BY column_name;"
    out=capture(['mariadb','-N',f'-h{MYSQL_HOST}',f'-P{MYSQL_PORT}',f'-u{MYSQL_USER}',f'-p{MYSQL_PASS}',an,'-e',sql])
    if len(out.splitlines())!=4: raise RuntimeError('MCA DB repair verification failed: '+out)

def cleanup_db(core,an): mysql(f'DROP DATABASE IF EXISTS `{core}`; DROP DATABASE IF EXISTS `{an}`;')

def archive(ref:str,dst:Path):
    dst.mkdir(parents=True,exist_ok=True)
    p1=subprocess.Popen(['git','archive',ref],stdout=subprocess.PIPE)
    p2=subprocess.run(['tar','-x','-C',str(dst)],stdin=p1.stdout,check=True); p1.stdout.close(); rc=p1.wait();
    if rc: raise RuntimeError('git archive failed')

def tree_digest(root:Path)->str:
    h=hashlib.sha256()
    for p in sorted(x for x in root.rglob('*') if x.is_file()):
        rel=p.relative_to(root).as_posix().encode(); data=p.read_bytes(); h.update(rel+b'\0'+hashlib.sha256(data).digest())
    return h.hexdigest()

def sentinels(f:Path):
    for d in ['config','data','storage']:
        p=f/d; p.mkdir(exist_ok=True); (p/'.v2131-preserve').write_text('preserve-'+d+'\n')
    cron=f/'server/team-points/cron.php'
    return {p.relative_to(f).as_posix():sha_file(p) for p in [f/'config/.v2131-preserve',f/'data/.v2131-preserve',f/'storage/.v2131-preserve',cron] if p.exists()}

def verify_sentinels(f:Path,before):
    after={rel:sha_file(f/rel) for rel in before}
    if after!=before: raise RuntimeError('preservation sentinel changed')

def compare_target(f:Path):
    for rel in RUNTIME:
        if (f/rel).read_bytes()!=git_bytes(QUAL,rel): raise RuntimeError('target byte mismatch '+rel)

def install(f:Path,tp:Path,extra=None,check=True):
    env=os.environ.copy(); env['P2K_PHP_BIN']=shutil.which('php') or 'php'; env['P2K_TP_CONFIG']=str(tp)
    if extra: env.update(extra)
    return run(['bash',str(PKG/'install-promote-to-king-v2.13.1.sh'),str(f)],env=env,check=check)

def qualify():
    work=Path(tempfile.mkdtemp(prefix='p2k-v2131-q-'))
    try:
        for i,(label,ref) in enumerate(BASES,1):
            print(f'=== qualify baseline {label} {ref} ===')
            f=work/f'b{i}'; archive(ref,f); preserve=sentinels(f); core=an=None
            try:
                core,an,tp=setup_db(f,f'b{i}')
                install(f,tp); compare_target(f); verify_db(core,an); verify_sentinels(f,preserve)
                d1=tree_digest(f); install(f,tp); d2=tree_digest(f)
                if d1!=d2: raise RuntimeError('idempotent reinstall changed tree')
                compare_target(f); verify_db(core,an); verify_sentinels(f,preserve)
            finally:
                if core and an: cleanup_db(core,an)
        # rollback proof
        print('=== qualify forced rollback ===')
        f=work/'rollback'; archive(BASES[-1][1],f); preserve=sentinels(f); core=an=None
        try:
            core,an,tp=setup_db(f,'rb'); before=tree_digest(f)
            r=install(f,tp,{'P2K_INSTALLER_TEST_FAIL_AFTER_ACTIVATION':'1'},check=False)
            if r.returncode!=3: raise RuntimeError(f'forced failure exit {r.returncode}, expected 3')
            if tree_digest(f)!=before: raise RuntimeError('full-tree rollback equality failed')
            verify_db(core,an); verify_sentinels(f,preserve)
        finally:
            if core and an: cleanup_db(core,an)
        # reject unknown bytes before DB/config dependency
        print('=== qualify unsupported source rejection ===')
        f=work/'reject'; archive(BASES[-1][1],f)
        p=f/'server/team-points-green/src/GreenRepository.php'; p.write_bytes(p.read_bytes()+b'\n// tamper\n'); before=sha_file(p)
        r=run(['bash',str(PKG/'install-promote-to-king-v2.13.1.sh'),str(f)],check=False)
        if r.returncode!=2 or sha_file(p)!=before: raise RuntimeError('unsupported-source rejection failed')
    finally:
        shutil.rmtree(work,ignore_errors=True)


def make_zip():
    z=DIST/(PKGNAME+'.zip')
    if z.exists(): z.unlink()
    with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as zz:
        for p in sorted(PKG.rglob('*')):
            if p.is_file(): zz.write(p,arcname=f'{PKGNAME}/{p.relative_to(PKG).as_posix()}')
    sha=sha_file(z); (DIST/(z.name+'.sha256')).write_text(f'{sha}  {z.name}\n')
    print('FINAL_ZIP',z); print('FINAL_SHA256',sha)

if __name__=='__main__':
    run(['git','cat-file','-e',QUAL+'^{commit}'])
    for _,ref in BASES: run(['git','cat-file','-e',ref+'^{commit}'])
    build_package(); qualify(); make_zip(); print('PASS: v2.13.1 incremental installer qualification complete')
