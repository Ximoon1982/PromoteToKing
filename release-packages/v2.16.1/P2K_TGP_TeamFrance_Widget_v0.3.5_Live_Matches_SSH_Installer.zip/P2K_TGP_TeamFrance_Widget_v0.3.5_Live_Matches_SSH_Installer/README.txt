P2K 2.16.1 — TGP and Team France standalone widget v0.3.5
=============================================================
New Live team-match section, admin configuration and GCWL league support.
Standalone SSH/SFTP installation only. DO NOT use P2K Release Control.

After uploading/unzipping the complete ZIP in the IONOS home directory:
  bash P2K_TGP_TeamFrance_Widget_v0.3.5_Live_Matches_SSH_Installer/install.sh /kunden/homepages/43/d141198007/htdocs/PromoteToKing --check
  bash P2K_TGP_TeamFrance_Widget_v0.3.5_Live_Matches_SSH_Installer/install.sh /kunden/homepages/43/d141198007/htdocs/PromoteToKing --apply

The installer checks all 20 payload checksums, validates PHP syntax, and refuses
unknown on-server source files. It retains independent original backups under
storage/standalone-widget-backups, copies code atomically and rolls back failed
installations. Never overwrites either widget's data/showcase.json or API cache.

Team France section: "Matchs en direct" (TGP: "Live Matches").
One or two rows (2/4 cards); opponent logos, league/friendly status, cadence,
mini MCA Bullet/Blitz/Rapid icons and a final-hour registration countdown.
Admin chooser reads the Chess.com club match index (time_class=live) and offers
the same Add, Enabled, Priority, order, Remove and Save controls as Daily.
Started matches retire only from verified upstream index or match details.
GCWL added for both clubs. Existing Daily and MCA configurations are preserved.
Iframe height reflects active Live rows; re-copy the embed HTML after changes.

Source commit: 826bdac55fef79d4d84ddadec69f28c516fd5dac
CI validation: https://github.com/Ximoon1982/PromoteToKing/actions/runs/45469112968
