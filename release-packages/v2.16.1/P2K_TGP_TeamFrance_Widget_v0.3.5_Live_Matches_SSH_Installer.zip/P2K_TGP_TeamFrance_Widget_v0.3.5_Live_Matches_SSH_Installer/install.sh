#!/usr/bin/env bash
# Standalone v0.3.5: checked offline installer for both club widgets.
set -Eeuo pipefail
usage(){ echo "Usage: bash install.sh /absolute/PromoteToKing/root [--check|--apply]" >&2; exit 2; }
[[ $# -ge 1 && $# -le 2 ]] || usage
ROOT="${1%/}"; MODE="${2:---apply}"
[[ "$ROOT" = /* && ( "$MODE" = "--check" || "$MODE" = "--apply" ) ]] || usage
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
[[ -d "$ROOT/TeamFrance/Widget" && -d "$ROOT/TGP/Widget" ]] || { echo "ERROR: both widgets must exist under ROOT" >&2; exit 1; }
command -v sha256sum >/dev/null || { echo "ERROR: sha256sum missing" >&2; exit 1; }
command -v sha1sum >/dev/null || { echo "ERROR: sha1sum missing" >&2; exit 1; }
# Verify the exact old Git source blob, including byte length and content.
git_blob_sha() { local file="$1" size; size="$(wc -c < "$file" | tr -d " ")"; { printf "blob %s\\0" "$size"; cat -- "$file"; } | sha1sum | cut -d" " -f1; }
PHP_BIN=/usr/bin/php8.5-cli
[[ -x "$PHP_BIN" ]] || PHP_BIN="$(command -v php || true)"
[[ -n "$PHP_BIN" && -x "$PHP_BIN" ]] || { echo "ERROR: PHP CLI missing" >&2; exit 1; }
[[ -f "$HERE/FILE_CHECKSUMS.tsv" ]] || { echo "ERROR: package manifest missing" >&2; exit 1; }
declare -a changes=()
count=0
while IFS=$'\t' read -r rel expected_old expected_new; do
  [[ -n "$rel" ]] || continue
  case "$rel" in TeamFrance/Widget/*|TGP/Widget/*) ;; *) echo "ERROR: invalid path: $rel" >&2; exit 1;; esac
  [[ "$rel" != *"/../"* && "$rel" != *"/./"* ]] || exit 1
  src="$HERE/payload/$rel"; dst="$ROOT/$rel"
  [[ -f "$src" && -f "$dst" && ! -L "$dst" ]] || { echo "ERROR: missing or symlink target: $rel" >&2; exit 1; }
  got="$(sha256sum "$src")"; got="${got%% *}"
  [[ "$got" == "$expected_new" ]] || { echo "ERROR: corrupted package: $rel" >&2; exit 1; }
  case "$rel" in
    *.php) "$PHP_BIN" -l "$src" >/dev/null || { echo "ERROR: PHP lint: $rel" >&2; exit 1; };;
    *.js) if command -v node >/dev/null 2>&1; then node --check "$src" || exit 1; fi;;
  esac
  current="$(sha256sum "$dst")"; current="${current%% *}"
  if [[ "$current" == "$expected_new" ]]; then
    printf 'Already installed: %s\n' "$rel"
  elif [[ "$(git_blob_sha "$dst")" == "$expected_old" ]]; then
    changes+=("$rel"); printf 'Ready to update: %s\n' "$rel"
  else
    printf 'ERROR: unknown installed source: %s\n  Current SHA256: %s\n  Expected old Git blob: %s\n' "$rel" "$current" "$expected_old" >&2
    echo "Refusing to overwrite custom/unrecognized files; reconcile baseline first." >&2
    exit 1
  fi
  count=$((count+1))
done < "$HERE/FILE_CHECKSUMS.tsv"
[[ "$count" -eq 20 ]] || { echo "ERROR: expected exactly 20 widget files, got $count" >&2; exit 1; }
echo "Verified $count package files; ${#changes[@]} need update."
if [[ "$MODE" == "--check" ]]; then echo "CHECK PASSED: no files were changed."; exit 0; fi
if [[ "${#changes[@]}" -eq 0 ]]; then echo "Already installed; no changes needed."; exit 0; fi
BACKUP="$ROOT/storage/standalone-widget-backups/widget-0.3.5-live-$(date -u '+%Y%m%dT%H%M%SZ')-$$"
mkdir -p "$BACKUP"
declare -a applied=()
rollback() {
  echo "ERROR: restoring replaced files; backups retained at $BACKUP" >&2
  for path in "${applied[@]}"; do cp -p -- "$BACKUP/$path" "$ROOT/$path" || true; done
}
trap rollback ERR
for rel in "${changes[@]}"; do
  src="$HERE/payload/$rel"; dst="$ROOT/$rel"; directory="$(dirname "$dst")"
  mkdir -p "$BACKUP/$(dirname "$rel")"
  cp -p -- "$dst" "$BACKUP/$rel"
  tmp="$(mktemp "$directory/.p2k-widget-live-XXXXXXXX")"
  cp -- "$src" "$tmp"; chmod 0644 "$tmp"; mv -f -- "$tmp" "$dst"
  applied+=("$rel")
  got="$(sha256sum "$dst")"; got="${got%% *}"
  wanted="$(sha256sum "$src")"; wanted="${wanted%% *}"
  [[ "$got" == "$wanted" ]] || { echo "ERROR: checksum mismatch after copy: $rel" >&2; false; }
done
trap - ERR
printf 'INSTALLED %s source files. Backups: %s\n' "${#applied[@]}" "$BACKUP"
echo "data/showcase.json, API caches, locks, OAuth, CRON and P2K release slots were not changed."
echo "Check each widget admin page and copy the refreshed fixed-height iframe HTML."
