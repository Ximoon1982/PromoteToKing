#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $# -ne 2 || ( "${2:-}" != "--check" && "${2:-}" != "--apply" ) || "${1:-}" != /* ]]; then
  echo "Usage: bash install.sh /absolute/PromoteToKing/root --check|--apply" >&2; exit 2
fi
ROOT="${1%/}"; MODE="$2"
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
[[ -d "$ROOT/TeamFrance/Widget" && -d "$ROOT/TGP/Widget" ]] || { echo "ERROR: wrong PromoteToKing root" >&2; exit 1; }
command -v sha1sum >/dev/null 2>&1 || { echo "ERROR: sha1sum required" >&2; exit 1; }
PHP_BIN=/usr/bin/php8.5-cli
[[ -x "$PHP_BIN" ]] || PHP_BIN="$(command -v php || true)"
[[ -n "$PHP_BIN" && -x "$PHP_BIN" ]] || { echo "ERROR: PHP CLI required" >&2; exit 1; }
git_blob_sha(){
  local file="$1" size
  size="$(wc -c < "$file" | tr -d '[:space:]')"
  { printf 'blob %s\0' "$size"; cat -- "$file"; } | sha1sum | cut -d' ' -f1
}
declare -a changes=()
count=0
while IFS=$'\t' read -r rel old_hash new_hash; do
  [[ -n "$rel" ]] || continue
  case "$rel" in TeamFrance/Widget/*|TGP/Widget/*) ;; *) echo "ERROR: invalid package path" >&2; exit 1 ;; esac
  [[ "$rel" != *"/../"* && "$rel" != *"/./"* ]] || exit 1
  src="$HERE/payload/$rel"; dst="$ROOT/$rel"
  [[ -f "$src" && -f "$dst" && ! -L "$dst" ]] || { echo "ERROR: missing or symlink file: $rel" >&2; exit 1; }
  [[ "$(git_blob_sha "$src")" == "$new_hash" ]] || { echo "ERROR: damaged installer file: $rel" >&2; exit 1; }
  case "$rel" in
    *.php) "$PHP_BIN" -l "$src" >/dev/null || { echo "ERROR: PHP lint failed: $rel" >&2; exit 1; } ;;
    *.js) if command -v node >/dev/null 2>&1; then node --check "$src" || exit 1; fi ;;
  esac
  current="$(git_blob_sha "$dst")"
  if [[ "$current" == "$new_hash" ]]; then
    echo "Already updated: $rel"
  elif [[ "$current" == "$old_hash" ]]; then
    changes+=("$rel")
    echo "Ready to update: $rel"
  else
    echo "ERROR: unknown/custom installed file: $rel" >&2
    echo "Installed Git blob SHA: $current" >&2
    echo "Expected v0.3.5 blob: $old_hash" >&2
    echo "Aborting without changes; reconcile this file first." >&2
    exit 1
  fi
  count=$((count+1))
done < "$HERE/FILE_CHECKSUMS.tsv"
[[ "$count" -eq 8 ]] || { echo "ERROR: expected 8 patch files, got $count" >&2; exit 1; }
echo "Verified $count files; ${#changes[@]} need updating."
if [[ "$MODE" == "--check" ]]; then echo "CHECK PASSED: no files modified."; exit 0; fi
if [[ "${#changes[@]}" -eq 0 ]]; then echo "Already installed; no files changed."; exit 0; fi
BACKUP="$ROOT/storage/standalone-widget-backups/widget-0.3.6-live-pubapi-$(date -u '+%Y%m%dT%H%M%SZ')-$$"
mkdir -p "$BACKUP"
declare -a applied=()
rollback(){
  echo "ERROR: restoring modified files from $BACKUP" >&2
  for item in "${applied[@]}"; do cp -p -- "$BACKUP/$item" "$ROOT/$item" || true; done
}
trap rollback ERR
for rel in "${changes[@]}"; do
  src="$HERE/payload/$rel"; dst="$ROOT/$rel"; folder="$(dirname "$dst")"
  mkdir -p "$BACKUP/$(dirname "$rel")"
  cp -p -- "$dst" "$BACKUP/$rel"
  tmp="$(mktemp "$folder/.p2k-live-pubapi-XXXXXXXX")"
  cp -- "$src" "$tmp"; chmod 0644 "$tmp"; mv -f -- "$tmp" "$dst"
  applied+=("$rel")
  [[ "$(git_blob_sha "$dst")" == "$(git_blob_sha "$src")" ]] || { echo "ERROR: destination mismatch: $rel" >&2; false; }
done
trap - ERR
echo "INSTALLED ${#applied[@]} files. Backup: $BACKUP"
echo "Widget configuration JSON, registration choices, OAuth, cache, CRON and public release slots were not modified."
echo "Test a Live match URL (for example https://www.chess.com/play/match/31195524) in the admin."
