Standalone Widget v0.3.6 — Chess.com Live PubAPI fix (P2K 2.16.1)
=================================================================
For Team France + The Golden Phoenix, upgrading existing widget v0.3.5.
DO NOT upload to P2K Release Control. These widgets serve from physical directories.

After uploading/extracting this ZIP in your IONOS SSH home:
  bash P2K_TGP_TeamFrance_Widget_v0.3.6_Live_PubAPI_Fix_SSH_Installer/install.sh /kunden/homepages/43/d141198007/htdocs/PromoteToKing --check
  bash P2K_TGP_TeamFrance_Widget_v0.3.6_Live_PubAPI_Fix_SSH_Installer/install.sh /kunden/homepages/43/d141198007/htdocs/PromoteToKing --apply

Checks all eight source files before modifying anything. Won't overwrite unknown
custom changes. Creates backups under storage/standalone-widget-backups and
rolls back on copy failure. Preserves configuration JSON and API caches.

GitHub Actions probe 2026-11-24: /pub/match/live/31195524 HTTP 200;
the Daily endpoint returned 404. Live details had
settings.time_class=lightning, settings.time_control=120, increment=0.
The Team France public club index returned two registered Daily matches and
zero registered Live matches. Scheduled Live matches cannot be discovered
automatically from this index; paste the Live match URL or ID in the admin.

Fixes: distinct Live endpoint; classify index records by URL, not speed class;
validate scheduled Live details; retain seconds+increment control and
opponent information; display informative index-empty guidance.
Existing Daily behavior and data are unchanged.
