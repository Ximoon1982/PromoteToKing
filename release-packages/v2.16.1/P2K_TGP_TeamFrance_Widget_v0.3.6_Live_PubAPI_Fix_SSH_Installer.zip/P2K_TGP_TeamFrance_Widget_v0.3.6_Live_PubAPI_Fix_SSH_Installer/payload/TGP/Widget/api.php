<?php
declare(strict_types=1);

require_once __DIR__ . '/src/Store.php';
require_once __DIR__ . '/src/ChessApi.php';
require_once __DIR__ . '/src/Auth.php';

use TGP\Widget\Auth;
use TGP\Widget\ChessApi;
use TGP\Widget\ChessApiException;
use TGP\Widget\RevisionConflict;
use TGP\Widget\Store;

$config = require __DIR__ . '/config.php';
$teamSlug = strtolower(trim((string)($config['team_slug'] ?? 'the-golden-phoenix')));
$sessionLifetime = max(300, (int)($config['admin_session_seconds'] ?? 3600));
$store = new Store(__DIR__, max(4, (int)($config['max_configured_matches'] ?? 100)));
$chess = new ChessApi(
    __DIR__ . '/data/cache',
    (string)($config['user_agent'] ?? 'TGP-Match-Showcase/0.2.0'),
    max(0, (int)($config['cache_ttl_match_seconds'] ?? 45)),
    max(0, (int)($config['cache_ttl_club_seconds'] ?? 300)),
);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Cache-Control: no-store');

function reply(int $status, array $payload): never {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function body_json(): array {
    $raw = file_get_contents('php://input');
    if ($raw === false || strlen($raw) > 262144) throw new InvalidArgumentException('Invalid request body.');
    if (trim($raw) === '') return [];
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) throw new InvalidArgumentException('Request body must be JSON.');
    return $decoded;
}
function request_method(string $expected): void {
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== $expected) throw new RuntimeException('Method not allowed.', 405);
}
function match_reference_id(string $reference): string {
    $reference = trim($reference);
    if ($reference === '') return '';
    if (preg_match('/^[0-9]{1,18}$/D', $reference)) return $reference;
    $patterns = [
        '~(?:api\.chess\.com/pub/match/|/match/)([0-9]{1,18})(?:[/?#]|$)~i',
        '~/(?:club/)?matches/(?:[^/?#]+/)*([0-9]{1,18})(?:[/?#]|$)~i',
        '~(?:^|[-_/])([0-9]{4,18})(?:[/?#]|$)~',
        '~[?&](?:id|match|match_id)=([0-9]{1,18})(?:&|$)~i',
    ];
    foreach ($patterns as $pattern) if (preg_match($pattern, $reference, $m)) return $m[1];
    return '';
}
function slug_key(string $value): string {
    $value = rawurldecode(trim($value));
    $path = (string)(parse_url($value, PHP_URL_PATH) ?: '');
    if ($path !== '') {
        $parts = array_values(array_filter(explode('/', trim($path, '/')), static fn($part) => $part !== ''));
        if ($parts !== []) $value = (string)end($parts);
    }
    $value = strtolower(trim($value));
    if (function_exists('iconv')) {
        $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if (is_string($ascii) && $ascii !== '') $value = strtolower($ascii);
    }
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? $value;
    return trim($value, '-');
}
function row_match_id(array $row): string {
    foreach (['match_id', 'id', '@id', 'url'] as $field) {
        $value = trim((string)($row[$field] ?? ''));
        if ($value === '') continue;
        if (preg_match('/(?:match\/|matches\/(?:[^\/?#]+\/)*)?([0-9]{1,18})(?:[\/?#]|$)/i', $value, $m)) return $m[1];
    }
    return '';
}
function club_slug_from_url(string $value): string {
    $value = trim($value);
    if ($value === '') return '';
    $path = trim((string)(parse_url($value, PHP_URL_PATH) ?: ''), '/');
    $parts = $path === '' ? [] : array_values(array_filter(explode('/', $path), static fn(string $part): bool => $part !== ''));
    foreach ($parts as $i => $part) {
        if (strtolower($part) === 'club' && isset($parts[$i + 1])) return strtolower(rawurldecode((string)$parts[$i + 1]));
    }
    return $parts !== [] ? strtolower(rawurldecode((string)end($parts))) : '';
}
function title_from_slug(string $slug): string {
    $slug = trim($slug);
    if ($slug === '') return 'Opponent';
    return ucwords(str_replace(['-', '_'], ' ', $slug));
}
/** Index time_class is the speed (lightning/blitz/standard) for Live matches. */
function match_index_type(array $row, string $wanted): bool {
    $class = strtolower(trim((string)($row['time_class'] ?? '')));
    $api = strtolower(trim((string)($row['@id'] ?? '')));
    $web = strtolower(trim((string)($row['url'] ?? '')));
    $isLive = str_contains($api, '/pub/match/live/')
        || str_contains($web, '/club/matches/live/')
        || str_contains($web, '/play/match/');
    if ($isLive || $class === 'live') return $wanted === 'live';
    return $wanted === 'daily' && $class === 'daily';
}
function match_api_path(string $matchId, string $timeClass): string {
    return 'https://api.chess.com/pub/match/' . ($timeClass === 'live' ? 'live/' : '') . rawurlencode($matchId);
}
function match_web_path(string $matchId, string $teamSlug, string $timeClass): string {
    return $timeClass === 'live'
        ? 'https://www.chess.com/play/match/' . rawurlencode($matchId)
        : 'https://www.chess.com/club/matches/' . rawurlencode($teamSlug) . '/' . rawurlencode($matchId);
}
function live_control_display(array $match): string {
    $settings = is_array($match['settings'] ?? null) ? $match['settings'] : [];
    $raw = trim((string)($settings['time_control'] ?? $match['time_control'] ?? ''));
    $inc = max(0, (int)($settings['time_increment'] ?? $match['time_increment'] ?? 0));
    if (preg_match('/^([0-9]+)(?:[+]([0-9]+))?$/D', $raw, $parts)) {
        $seconds = (int)$parts[1];
        if (isset($parts[2])) $inc = (int)$parts[2];
        $minutes = $seconds / 60;
        $display = abs($minutes - round($minutes)) < 0.000001
            ? (string)(int)round($minutes)
            : rtrim(rtrim(sprintf('%.2f', $minutes), '0'), '.');
        return $display . '+' . $inc;
    }
    return $raw;
}

function registration_index_rows(array $index, string $teamSlug, string $timeClass = 'daily'): array {
    $registered = is_array($index['registered'] ?? null) ? $index['registered'] : [];
    $rows = []; $seen = [];
    foreach ($registered as $row) {
        if (!is_array($row) || !match_index_type($row, $timeClass)) continue;
        $id = row_match_id($row);
        if ($id === '' || isset($seen[$id])) continue;
        $seen[$id] = true;
        $opponentSlug = club_slug_from_url((string)($row['opponent'] ?? ''));
        $rows[] = [
            'matchId' => $id,
            'name' => trim((string)($row['name'] ?? '')) ?: 'Match #' . $id,
            'apiUrl' => trim((string)($row['@id'] ?? '')) ?: match_api_path($id, $timeClass),
            'url' => trim((string)($row['url'] ?? '')) ?: match_web_path($id, $teamSlug, $timeClass),
            'opponentSlug' => $opponentSlug,
            'opponentName' => title_from_slug($opponentSlug),
            'timeClass' => $timeClass,
        ];
    }
    return $rows;
}
function club_daily_match_ids(array $index, string $timeClass = 'daily'): array {
    $ids = [];
    foreach (['registered', 'in_progress', 'finished'] as $bucketName) {
        $bucket = is_array($index[$bucketName] ?? null) ? $index[$bucketName] : [];
        foreach ($bucket as $row) {
            if (!is_array($row) || !match_index_type($row, $timeClass)) continue;
            $id = row_match_id($row);
            if ($id !== '') $ids[$id] = true;
        }
    }
    return $ids;
}
/**
 * Only positive Chess.com club-index evidence qualifies a Daily match for
 * automatic removal. An absent ID, failed fetch or delayed registration list
 * must never result in deletion. Registration wins conflicting index buckets.
 */
function confirmed_started_daily_ids(array $index, string $timeClass = 'daily'): array {
    $registered = [];
    foreach (is_array($index['registered'] ?? null) ? $index['registered'] : [] as $row) {
        if (!is_array($row) || !match_index_type($row, $timeClass)) continue;
        $id = row_match_id($row);
        if ($id !== '') $registered[$id] = true;
    }
    $started = [];
    foreach (['in_progress','finished'] as $status) {
        foreach (is_array($index[$status] ?? null) ? $index[$status] : [] as $row) {
            if (!is_array($row) || !match_index_type($row, $timeClass)) continue;
            $id = row_match_id($row);
            if ($id !== '' && !isset($registered[$id])) $started[$id] = true;
        }
    }
    return array_keys($started);
}
function is_started_daily_status(mixed $status): bool {
    return in_array(strtolower(trim((string)$status)), ['in_progress','finished','completed','started','in progress'], true);
}
function club_daily_match_map(array $index, string $teamSlug, string $wantedTimeClass = 'daily'): array {
    $map = [];
    foreach (['registered', 'in_progress', 'finished'] as $bucketName) {
        $bucket = is_array($index[$bucketName] ?? null) ? $index[$bucketName] : [];
        foreach ($bucket as $row) {
            if (!is_array($row)) continue;
            if (!match_index_type($row, $wantedTimeClass)) continue;
            $id = row_match_id($row);
            if ($id === '') continue;
            $opponentSlug = club_slug_from_url((string)($row['opponent'] ?? ''));
            $map[$id] = [
                'matchId' => $id,
                'name' => trim((string)($row['name'] ?? '')) ?: 'Match #' . $id,
                'apiUrl' => trim((string)($row['@id'] ?? '')) ?: match_api_path($id, $wantedTimeClass),
                'url' => trim((string)($row['url'] ?? '')) ?: match_web_path($id, $teamSlug, $wantedTimeClass),
                'opponentSlug' => $opponentSlug,
                'opponentName' => title_from_slug($opponentSlug),
                'status' => $bucketName,
            ];
        }
    }
    return $map;
}
function admin_item_payload(array $item, array $matchMap, string $teamSlug): array {
    $id = (string)($item['matchId'] ?? '');
    $match = $matchMap[$id] ?? [
        'matchId' => $id,
        'name' => 'Match #' . $id,
        'url' => 'https://www.chess.com/club/matches/' . rawurlencode($teamSlug) . '/' . rawurlencode($id),
        'opponentName' => 'Opponent',
    ];
    return array_merge($item, ['resolved' => isset($matchMap[$id]), 'match' => $match, 'error' => isset($matchMap[$id]) ? '' : 'Not present in the current club match index.']);
}
function resolve_match_reference(string $reference, string $teamSlug, ChessApi $chess, string $timeClass = 'daily'): string {
    $id = match_reference_id($reference);
    if ($id !== '') return $id;
    $needle = slug_key($reference);
    if ($needle === '') return '';
    $index = $chess->clubMatches($teamSlug, true);
    $matches = [];
    foreach ($index as $bucket) {
        if (!is_array($bucket)) continue;
        foreach ($bucket as $row) {
            if (!is_array($row)) continue;
            if (!match_index_type($row, $timeClass)) continue;
            $candidateId = row_match_id($row);
            if ($candidateId === '') continue;
            $keys = [];
            foreach (['url', '@id', 'name'] as $field) {
                $value = trim((string)($row[$field] ?? ''));
                if ($value !== '') $keys[] = slug_key($value);
            }
            if (in_array($needle, $keys, true)) $matches[$candidateId] = true;
        }
    }
    $ids = array_keys($matches);
    if (count($ids) === 1) return $ids[0];
    if (count($ids) > 1) throw new InvalidArgumentException('That match slug is ambiguous. Paste the Chess.com match URL or numeric id instead.');
    return '';
}
function team_slug_from_team(mixed $team): string {
    if (!is_array($team)) return '';
    foreach (['@id', 'url'] as $field) {
        $value = trim((string)($team[$field] ?? ''));
        if ($value === '') continue;
        $path = trim((string)(parse_url($value, PHP_URL_PATH) ?: ''), '/');
        $parts = $path === '' ? [] : array_values(array_filter(explode('/', $path), static fn($x) => $x !== ''));
        foreach ($parts as $i => $part) {
            if (strtolower($part) === 'club' && isset($parts[$i + 1])) return strtolower(rawurldecode($parts[$i + 1]));
        }
        if ($parts !== []) return strtolower(rawurldecode((string)end($parts)));
    }
    return '';
}
function match_teams(array $match): array {
    $teams = $match['teams'] ?? [];
    return is_array($teams) ? array_values(array_filter($teams, 'is_array')) : [];
}
function validate_match(array $match, string $teamSlug, string $timeClass = 'daily'): array {
    $actualTimeClass = strtolower(trim((string)($match['time_class'] ?? ($match['settings']['time_class'] ?? ''))));
    $apiPath = (string)parse_url((string)($match['@id'] ?? ''), PHP_URL_PATH);
    $webPath = (string)parse_url((string)($match['url'] ?? ''), PHP_URL_PATH);
    $isLive = str_starts_with($apiPath, '/pub/match/live/')
        || str_starts_with($webPath, '/club/matches/live/')
        || str_starts_with($webPath, '/play/match/');
    if ($timeClass === 'live' && !$isLive)
        throw new InvalidArgumentException('Chess.com did not identify this as a Live team match.');
    if ($timeClass === 'daily' && ($isLive || ($actualTimeClass !== '' && $actualTimeClass !== 'daily')))
        throw new InvalidArgumentException('Expected a Daily Chess team match.');
    $our = null; $opponent = null;
    foreach (match_teams($match) as $team) {
        if (team_slug_from_team($team) === $teamSlug) $our = $team;
        elseif ($opponent === null) $opponent = $team;
    }
    if (!is_array($our)) throw new InvalidArgumentException('This match does not include the configured club ' . $teamSlug . '.');
    if (!is_array($opponent)) {
        foreach (match_teams($match) as $team) if ($team !== $our) { $opponent = $team; break; }
    }
    if (!is_array($opponent)) throw new InvalidArgumentException('Unable to determine the opponent club.');
    return [$our, $opponent];
}
function league_codes(string $name, array $config): array {
    $codes = is_array($config['league_acronyms'] ?? null) ? $config['league_acronyms'] : [];
    $matches = [];
    foreach ($codes as $code) {
        $code = trim((string)$code);
        if ($code === '') continue;
        if (preg_match('/(^|[^A-Z0-9])' . preg_quote($code, '/') . '([^A-Z0-9]|$)/i', $name)) $matches[] = $code;
    }
    return $matches;
}
function card_payload(array $match, string $matchId, bool $urgent, string $teamSlug, ChessApi $chess, array $config, string $timeClass = 'daily'): array {
    [$our, $opponent] = validate_match($match, $teamSlug, $timeClass);
    $opponentSlug = team_slug_from_team($opponent);
    $opponentName = trim((string)($opponent['name'] ?? '')) ?: ($opponentSlug !== '' ? str_replace('-', ' ', $opponentSlug) : 'Opponent');
    $logo = '';
    if ($opponentSlug !== '') {
        try {
            $club = $chess->club($opponentSlug);
            $logo = trim((string)($club['icon'] ?? $club['image'] ?? ''));
        } catch (Throwable) {}
    }
    $name = trim((string)($match['name'] ?? '')) ?: 'Match #' . $matchId;
    $codes = league_codes($name, $config);
    $apiUrl = trim((string)($match['@id'] ?? '')) ?: match_api_path($matchId, $timeClass);
    $url = trim((string)($match['url'] ?? '')) ?: match_web_path($matchId, $teamSlug, $timeClass);
    $start = $match['start_time'] ?? $match['startTime'] ?? null;
    $start = is_numeric($start) && (int)$start > 0 ? (int)$start : null;
    return [
        'matchId' => $matchId,
        'timeClass' => $timeClass,
        'name' => $name,
        'url' => $url,
        'apiUrl' => $apiUrl,
        'startTime' => $start,
        'urgent' => $urgent,
        'category' => $codes !== [] ? 'league' : 'friendly',
        'leagueAcronyms' => $codes,
        'opponentSlug' => $opponentSlug,
        'opponentName' => $opponentName,
        'opponentLogo' => $logo,
        'settings' => is_array($match['settings'] ?? null) ? $match['settings'] : [],
        'time_control' => $timeClass === 'live' ? live_control_display($match) : ($match['time_control'] ?? ($match['settings']['time_control'] ?? null)),
        'liveTimeControl' => $timeClass === 'live' ? live_control_display($match) : null,
        'ourTeam' => $our,
        'opponentTeam' => $opponent,
        'status' => $match['status'] ?? null,
    ];
}
function item_payload(array $item, string $teamSlug, ChessApi $chess, array $config, string $timeClass = 'daily'): array {
    $id = (string)($item['matchId'] ?? '');
    try {
        $match = $timeClass === 'live' ? $chess->liveMatch($id) : $chess->match($id);
        return array_merge($item, ['resolved' => true, 'match' => card_payload($match, $id, ($item['urgent'] ?? false) === true, $teamSlug, $chess, $config, $timeClass)]);
    } catch (Throwable $e) {
        return array_merge($item, ['resolved' => false, 'error' => $e->getMessage(), 'match' => ['matchId'=>$id,'name'=>'Match #'.$id,'url'=>'https://www.chess.com/club/matches/'.rawurlencode($teamSlug).'/'.rawurlencode($id),'urgent'=>(($item['urgent']??false)===true)]]);
    }
}

$action = strtolower(trim((string)($_GET['action'] ?? 'cards')));
try {
    if ($action === 'cards') {
        request_method('GET');
        $state = $store->read();
        // Only positive Chess.com index evidence can retire configured cards.
        // Public reads use one cached club index; transient errors never delete cards.
        try {
            $index = $chess->clubMatches($teamSlug);
            $startedDaily = confirmed_started_daily_ids($index, 'daily');
            $startedLive = confirmed_started_daily_ids($index, 'live');
            if ($startedDaily !== [] || $startedLive !== [])
                $state = $store->pruneStartedMatches($startedDaily, $startedLive);
        } catch (ChessApiException $e) {
            // Keep all saved cards when the upstream index is unavailable.
        }
        $layout = $state['layout'] ?? ['arenaRows'=>1,'liveRows'=>1,'dailyRows'=>2];
        $dailyLimit = max(1, min(6, (int)($layout['dailyRows'] ?? 2) * 2));
        $liveLimit = max(1, min(4, (int)($layout['liveRows'] ?? 1) * 2));
        $cards = []; $liveCards = []; $newlyStarted = []; $newlyStartedLive = [];
        foreach (array_values(array_filter($state['items'], static fn(array $v): bool => ($v['enabled'] ?? true) === true)) as $item) {
            $payload = item_payload($item, $teamSlug, $chess, $config, 'daily');
            $card = $payload['match'];
            if (!empty($payload['resolved']) && is_started_daily_status($card['status'] ?? null)) {
                $newlyStarted[] = (string)$item['matchId'];
                continue;
            }
            $cards[] = $card;
            if (count($cards) >= $dailyLimit) break;
        }
        foreach (array_values(array_filter($state['liveItems'], static fn(array $v): bool => ($v['enabled'] ?? true) === true)) as $item) {
            $payload = item_payload($item, $teamSlug, $chess, $config, 'live');
            $card = $payload['match'];
            if (!empty($payload['resolved']) && is_started_daily_status($card['status'] ?? null)) {
                $newlyStartedLive[] = (string)$item['matchId'];
                continue;
            }
            $liveCards[] = $card;
            if (count($liveCards) >= $liveLimit) break;
        }
        if ($newlyStarted !== [] || $newlyStartedLive !== [])
            $store->pruneStartedMatches($newlyStarted, $newlyStartedLive);
        reply(200, [
            'ok'=>true,'version'=>$config['version'] ?? '0.3.5','teamSlug'=>$teamSlug,
            'cards'=>$cards,'liveCards'=>$liveCards,
            'arenas'=>array_slice(array_values(array_filter($state['arenas'] ?? [],
                static fn(array $a): bool => ($a['active'] ?? false) === true)),
                0, max(2, min(4, (int)($layout['arenaRows'] ?? 1) * 2))),
            'layout'=>$layout,
        ]);
    }

    if ($action === 'admin-status') {
        request_method('GET');
        reply(200, ['ok'=>true,'session'=>Auth::info($sessionLifetime),'teamSlug'=>$teamSlug,'teamName'=>$config['team_name'] ?? $teamSlug]);
    }

    if ($action === 'admin-session') {
        request_method('POST');
        Auth::enforceSameOrigin(true);
        $body = body_json();
        $assertion = trim((string)($body['bootstrap_assertion'] ?? ''));
        if ($assertion === '') throw new RuntimeException('Chess.com OAuth login is required.', 401);
        $root = dirname(__DIR__, 2);
        $bootstrap = $root . '/server/team-points/src/bootstrap.php';
        if (!is_file($bootstrap)) throw new RuntimeException('P2K OAuth bootstrap is unavailable.', 503);
        require_once $bootstrap;
        $username = \P2K\TeamPoints\OAuthSession::verifyAdminBootstrapAssertion($assertion);
        if ($username === '') throw new RuntimeException('OAuth identity assertion is invalid or expired.', 401);
        $club = $chess->club($teamSlug, true);
        if (!Auth::clubProfileHasAdmin($club, $username)) throw new RuntimeException('The authenticated Chess.com account is not a current administrator of ' . $teamSlug . '.', 403);
        reply(200, ['ok'=>true,'session'=>Auth::create($username, $sessionLifetime),'teamSlug'=>$teamSlug]);
    }

    if ($action === 'admin-state') {
        request_method('GET');
        Auth::requireAdmin($sessionLifetime, false);
        $state = $store->read();
        try {
            $index = $chess->clubMatches($teamSlug);
        } catch (ChessApiException $e) {
            $index = []; // Admin editing remains available during Chess.com outages.
        }
        if ($index !== []) {
            $startedDaily = confirmed_started_daily_ids($index, 'daily');
            $startedLive = confirmed_started_daily_ids($index, 'live');
            if ($startedDaily !== [] || $startedLive !== [])
                $state = $store->pruneStartedMatches($startedDaily, $startedLive);
        }
        $dailyMap = club_daily_match_map($index, $teamSlug, 'daily');
        $liveMap = club_daily_match_map($index, $teamSlug, 'live');
        $items = []; $liveItems = [];
        foreach ($state['items'] as $item) $items[] = admin_item_payload($item, $dailyMap, $teamSlug);
        // Chess.com currently omits scheduled Live matches from the public
        // 'registered' index. Resolve only the first four configured missing
        // Live IDs through the dedicated (cached) detail endpoint, not by
        // assuming that index absence means a missing/invalid match.
        $detailsChecked = 0;
        foreach ($state['liveItems'] as $item) {
            $id = (string)($item['matchId'] ?? '');
            if ($id !== '' && !isset($liveMap[$id]) && $detailsChecked < 4) {
                $detailsChecked++;
                try {
                    $detail = $chess->liveMatch($id);
                    [, $opponent] = validate_match($detail, $teamSlug, 'live');
                    $liveMap[$id] = [
                        'matchId' => $id,
                        'name' => trim((string)($detail['name'] ?? '')) ?: 'Match #' . $id,
                        'url' => trim((string)($detail['url'] ?? '')) ?: match_web_path($id, $teamSlug, 'live'),
                        'apiUrl' => match_api_path($id, 'live'),
                        'opponentSlug' => team_slug_from_team($opponent),
                        'opponentName' => trim((string)($opponent['name'] ?? '')) ?: 'Opponent',
                        'timeClass' => 'live',
                        'status' => (string)($detail['status'] ?? ''),
                    ];
                } catch (Throwable) {
                    // Never misclassify an unreturned match as started.
                }
            }
            $liveItems[] = admin_item_payload($item, $liveMap, $teamSlug);
        }
        reply(200, [
            'ok'=>true,'schemaVersion'=>$state['schemaVersion'],'revision'=>$state['revision'],
            'updatedAt'=>$state['updatedAt'],'items'=>$items,'liveItems'=>$liveItems,
            'arenas'=>$state['arenas'] ?? [],
            'layout'=>$state['layout'] ?? ['arenaRows'=>1,'liveRows'=>1,'dailyRows'=>2],
            'teamSlug'=>$teamSlug,'teamName'=>$config['team_name'] ?? $teamSlug,
        ]);
    }

    if ($action === 'registration-list') {
        request_method('GET');
        Auth::requireAdmin($sessionLifetime, false);
        $timeClass = strtolower(trim((string)($_GET['timeClass'] ?? 'daily')));
        if (!in_array($timeClass, ['daily','live'], true))
            throw new InvalidArgumentException('Unknown match type.');
        $force = (string)($_GET['refresh'] ?? '') === '1';
        $index = $chess->clubMatches($teamSlug, $force);
        $started = confirmed_started_daily_ids($index, $timeClass);
        if ($started !== []) $store->pruneStartedMatches(
            $timeClass === 'daily' ? $started : [],
            $timeClass === 'live' ? $started : []
        );
        reply(200, [
            'ok'=>true,'source'=>'https://api.chess.com/pub/club/' . $teamSlug . '/matches',
            'timeClass'=>$timeClass,'loadedAt'=>time(),
            'matches'=>registration_index_rows($index, $teamSlug, $timeClass),
        ]);
    }

    if (str_starts_with($action, 'arena-discovery-')) {
        // The existing TGP / Team France admin authorization and CSRF
        // protections also cover discovery. Public widget readers cannot scan.
        // Standalone widget code is served from the physical club directory,
        // not P2K's immutable routed release slot. Keep this service local.
        $root = dirname(__DIR__, 2);
        require_once __DIR__ . '/src/StandaloneArenaDiscoveryService.php';
        $discovery = new \P2K\EventsShowcase\StandaloneArenaDiscoveryService(__DIR__, $root);
        if ($action === 'arena-discovery-state') {
            request_method('GET');
            Auth::requireAdmin($sessionLifetime, false);
            reply(200, array_merge(['ok'=>true], $discovery->read()));
        }
        request_method('POST');
        Auth::requireAdmin($sessionLifetime, true);
        $body = body_json();
        if ($action === 'arena-discovery-resolve') {
            $reference=trim((string)($body['reference'] ?? ''));
            reply(200, ['ok'=>true,'organizer'=>$discovery->resolveOrganizer($reference)]);
        }
        if ($action === 'arena-discovery-save') {
            if (!is_array($body['organizers'] ?? null)) throw new InvalidArgumentException('Organizer list must be an array.');
            $revision = filter_var($body['revision'] ?? null, FILTER_VALIDATE_INT);
            if ($revision === false || $revision < 0) throw new InvalidArgumentException('Invalid organizer revision.');
            reply(200, array_merge(['ok'=>true], $discovery->saveOrganizers($body['organizers'], $revision)));
        }
        if ($action === 'arena-discovery-begin') {
            reply(200, array_merge(['ok'=>true], $discovery->begin()));
        }
        if ($action === 'arena-discovery-cancel') {
            reply(200, array_merge(['ok'=>true], $discovery->cancel((string)($body['scanId'] ?? ''))));
        }
        if ($action === 'arena-discovery-page') {
            $scanId = trim((string)($body['scanId'] ?? ''));
            $page = filter_var($body['page'] ?? null, FILTER_VALIDATE_INT);
            if ($page === false || $page < 1 || $page > \P2K\EventsShowcase\StandaloneArenaDiscoveryService::MAX_PAGES)
                throw new InvalidArgumentException('Invalid arena scan page.');
            $known = [];
            foreach ($store->read()['arenas'] as $arena) {
                $path = (string)parse_url((string)($arena['link'] ?? ''), PHP_URL_PATH);
                if (preg_match('~/(?:play/arena|tournament/live/arena)/(?:[^/]*?-)?([0-9]{4,15})(?:/|$)~i', $path, $m))
                    $known[] = $m[1];
            }
            reply(200, array_merge(['ok'=>true],
                $discovery->scanPage($scanId, $page, $known)));
        }
        throw new InvalidArgumentException('Unknown arena discovery operation.');
    }

    if ($action === 'resolve') {
        request_method('POST');
        Auth::requireAdmin($sessionLifetime, true);
        $body = body_json();
        $timeClass = strtolower(trim((string)($body['timeClass'] ?? 'daily')));
        if (!in_array($timeClass, ['daily','live'], true))
            throw new InvalidArgumentException('Unknown match type.');
        $reference = trim((string)($body['reference'] ?? ''));
        $id = resolve_match_reference($reference, $teamSlug, $chess, $timeClass);
        if ($id === '') throw new InvalidArgumentException('No ' . $timeClass . ' match for this club matched the URL, ID or slug.');
        $match = $timeClass === 'live' ? $chess->liveMatch($id, true) : $chess->match($id, true);
        $normalized = card_payload($match, $id, false, $teamSlug, $chess, $config, $timeClass);
        if (is_started_daily_status($normalized['status'] ?? null))
            throw new InvalidArgumentException('This ' . $timeClass . ' match has already started or finished and cannot be added.');
        reply(200, ['ok'=>true,'match'=>$normalized]);
    }

    if ($action === 'save') {
        request_method('POST');
        Auth::requireAdmin($sessionLifetime, true);
        $body = body_json();
        $expected = filter_var($body['revision'] ?? null, FILTER_VALIDATE_INT);
        if ($expected === false || $expected < 0)
            throw new InvalidArgumentException('revision must be a non-negative integer.');
        // Arena/layout-only saves preserve both lists even when an editor has
        // unsaved local changes; new match IDs are validated by time_class.
        $current = $store->read();
        $currentIds = [];
        foreach (['daily'=>'items', 'live'=>'liveItems'] as $type=>$field) {
            foreach ($current[$field] as $existing)
                $currentIds[$type . ':' . (string)$existing['matchId']] = true;
        }
        $newIds = [];
        $allIds = [];
        foreach (['daily'=>'items', 'live'=>'liveItems'] as $type=>$field) {
            $rows = $body[$field] ?? $current[$field];
            if (!is_array($rows)) throw new InvalidArgumentException($field . ' must be an array.');
            foreach ($rows as $item) {
                if (!is_array($item)) throw new InvalidArgumentException('Invalid configured match.');
                $id = trim((string)($item['matchId'] ?? ''));
                if ($id === '' || !preg_match('/^[0-9]{1,18}$/D', $id))
                    throw new InvalidArgumentException('Invalid match id.');
                if (isset($allIds[$id]) && $allIds[$id] !== $type)
                    throw new InvalidArgumentException('A match cannot be configured as both Live and Daily.');
                $allIds[$id] = $type;
                if (!isset($currentIds[$type . ':' . $id])) $newIds[$id] = $type;
            }
        }
        if ($newIds !== []) {
            $index = $chess->clubMatches($teamSlug);
            $known = [];
            $started = [];
            foreach (['daily','live'] as $type) {
                $known[$type] = club_daily_match_ids($index, $type);
                $started[$type] = array_fill_keys(confirmed_started_daily_ids($index, $type), true);
            }
            foreach ($newIds as $id=>$type) {
                if (isset($started[$type][$id]))
                    throw new InvalidArgumentException('This ' . $type . ' match has already started or finished.');
                if (isset($known[$type][$id])) continue;
                $detail = $type === 'live' ? $chess->liveMatch((string)$id) : $chess->match((string)$id);
                validate_match($detail, $teamSlug, $type);
                if (is_started_daily_status($detail['status'] ?? null))
                    throw new InvalidArgumentException('This ' . $type . ' match has already started or finished.');
            }
        }
        $saved = $store->save($body, (int)$expected);
        reply(200, array_merge(['ok'=>true], $saved));
    }

    if ($action === 'logout') {
        request_method('POST');
        Auth::requireAdmin($sessionLifetime, true);
        Auth::logout($sessionLifetime);
        reply(200, ['ok'=>true]);
    }

    reply(404, ['ok'=>false,'error'=>['message'=>'Unknown action.']]);
} catch (RevisionConflict $e) {
    reply(409, ['ok'=>false,'error'=>['message'=>$e->getMessage(),'code'=>'REVISION_CONFLICT'],'current'=>$e->current]);
} catch (InvalidArgumentException $e) {
    reply(400, ['ok'=>false,'error'=>['message'=>$e->getMessage(),'code'=>'INVALID_REQUEST']]);
} catch (ChessApiException $e) {
    $status = $e->status === 404 ? 404 : 502;
    reply($status, ['ok'=>false,'error'=>['message'=>$e->getMessage(),'code'=>'CHESS_API_ERROR']]);
} catch (RuntimeException $e) {
    $status = $e->getCode();
    if ($status < 400 || $status > 599) $status = 500;
    reply($status, ['ok'=>false,'error'=>['message'=>$e->getMessage(),'code'=>'RUNTIME_ERROR']]);
} catch (Throwable $e) {
    error_log('TGP Widget: ' . $e);
    reply(500, ['ok'=>false,'error'=>['message'=>'The Match Showcase encountered an unexpected server error.','code'=>'SERVER_ERROR']]);
}
