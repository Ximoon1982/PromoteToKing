P2K 2.16.0 maintenance repair candidate
Source commit: 87cd8c4fdc1000d7ec0acde1bde76e4d4b636e24
Accepted production baseline: 2.15.11-460a449fc198
Upload this ZIP directly through Release Control, inspect preview, and promote only after validation.
Corrections: active-slot maintenance path, fail-closed missing release state, shared achievement queue path, finished-only fair-play, preserved PIR time budget.
The home-directory cron helper is EXTERNAL to Release Control and is NOT rewritten by upload or promotion. AFTER promotion, run the approved cron installer from the promoted slot and verify real execution. Existing historical score data and achievement queue are not reset.
