P2K 2.16.0 maintenance routing and finished-only Fair Play preview candidate.
Upload this entire ZIP directly in Release Control. Preview first; promote only after validation.
Accepted public base: 2.15.11-460a449fc198
Source code commit: ed0be3fd445b617864c51572967e8bf812a9ca12
Warning: The installed $HOME/.p2k maintenance cron helper is OUTSIDE the release slot. Promoting this candidate alone does not rewrite that helper. Reinstall the helper using the updated installer after promotion; do not assume maintenance is restored until that step and a real run are verified.
