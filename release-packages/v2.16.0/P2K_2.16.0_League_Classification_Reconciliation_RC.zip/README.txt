P2K 2.16.0 Green league classification reconciliation
Source HEAD c9d6f7a9883ecd3ba3a760f86b7f0da5d15d189c
Release Control: Upload -> Preview -> Promote.
Existing every-five-minute maintenance automatically processes up to 50 mismatched Green league flags, with statistics in the maintenance diagnostics log. No separate cron setup needed.
Only the league flag and metadata timestamp are changed. The existing achievement queue, board/game data and all schedules remain intact.
