P2K 2.16.0 maintenance diagnostics, Release Control candidate
Source HEAD: dd922c06707180569a3fc362c6fa71d5dfe6844a
Accepted installed release: 2.16.0-87cd8c4fdc10
Use Release Control upload -> preview -> promote.
After promotion, refresh the external helper:
ROOT="/kunden/homepages/43/d141198007/htdocs/PromoteToKing"
bash "$ROOT/data/runtime-v280/release-control/runtime-trees/2.16.0-dd922c067071/app/server/team-points/bin/cutover-blue-maintenance-cron.sh" "$ROOT"
Diagnostics: tail -n 100 "$HOME/.p2k/team-points-maintenance.log"
Logs are private, rotated at 64KB; no cron frequency, pipeline or queue changes.
